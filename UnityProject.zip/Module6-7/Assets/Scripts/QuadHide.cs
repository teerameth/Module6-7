﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class QuadHide : MonoBehaviour
{
    public GameObject referenceObject, exceptionObject;
    private MeshRenderer renderer;

    private void Start()
    {
        
    }
    void Update()
    {
        if(referenceObject.GetComponent<CanvasGroup>().alpha == 0 || exceptionObject.GetComponent<CanvasGroup>().alpha == 1)
        {
            gameObject.GetComponent<MeshRenderer>().enabled = false;
        }
        else
        {
            gameObject.GetComponent<MeshRenderer>().enabled = true;
        }
    }
}

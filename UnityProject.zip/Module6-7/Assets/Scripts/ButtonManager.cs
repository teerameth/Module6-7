﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ButtonManager : MonoBehaviour
{
    public int x, y, z, a;
    public GameObject stateController;
    public byte[] packet;
    public GameObject reconModeDropdown;
    public GameObject segmentModeDropdown;
    int gripperState = 0;
    
    private void send(byte[] packet)
    {
        stateController.GetComponent<StateController>().sendTCP(packet);
    }
        /// Event Tringger ///
    public void captureTemplate()
    {
        send(new byte[] { 3, 0 });
    }
    public void captureWorkspace()
    {
        send(new byte[] { 3, 1 });
    }
    public void connectAll()
    {
        send(new byte[] { 3, 2, 0 });
    }
    public void connectXY()
    {
        send(new byte[] { 3, 2, 1 });
    }
    public void connectZ()
    {
        send(new byte[] { 3, 2, 2});
    }
    public void homeAll()
    {
        send(new byte[] { 3, 3, 0 });
    }
    public void homeXY()
    {
        send(new byte[] {3, 3, 1 });
    }
    public void homeZ()
    {
        send(new byte[] { 3, 3, 2 });
    }
    public void center()
    {
        send(new byte[] { 3, 3, 3 });
    }
     public void parameterUpdateCUDA(int parameter)
    {
        stateController.GetComponent<StateController>().sendTCP(new byte[] { 2, 0, (byte)parameter});
    }
    public void parameterUpdateAutoRUN(int parameter)
    {
        stateController.GetComponent<StateController>().sendTCP(new byte[] { 2, 1, (byte)parameter});
    }
    public void parameterUpdateCircularMotion(int parameter)
    {
        stateController.GetComponent<StateController>().sendTCP(new byte[] { 2, 2, (byte)parameter});
    }
    public void run()
    {
        int reconstructionMode = reconModeDropdown.GetComponent<Michsky.UI.ModernUIPack.CustomDropdown>().index;
        int segmentationMode = segmentModeDropdown.GetComponent<Michsky.UI.ModernUIPack.CustomDropdown>().index;
        stateController.GetComponent<StateController>().sendTCP(new byte[] { 3, 5, (byte)stateController.GetComponent<StateController>().getState(), (byte)reconstructionMode, (byte)segmentationMode});
    }
    public void gripperToggle()
    {
        if (gripperState == 0) gripperState = 1;
        else gripperState = 0;
        stateController.GetComponent<StateController>().sendTCP(new byte[] { 3, 6, (byte)gripperState});
    }
    public void sendTJ()
    {
        stateController.GetComponent<StateController>().sendTCP(new byte[] { 3, 7, (byte)(x/256), (byte)(x % 256), (byte)(y/256), (byte)(y%256) , (byte)(z/256), (byte)(z%256) , (byte)(a/256), (byte)(a%256)});
    }
}

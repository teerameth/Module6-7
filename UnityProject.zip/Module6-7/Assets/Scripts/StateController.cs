﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;
using System.IO;
using System.Net.Sockets;
using System.Text;

public class StateController : MonoBehaviour
{
    public bool connected = false;
    TcpClient TCPsocket;
    public NetworkStream TCPstream;
    StreamWriter TCPwriter;
    StreamReader TCPreader;
    public String Host = "127.0.0.1";
    public Int32 Port = 12345;
    byte[] bufferIn = new byte[64];

    string[] WindowName = {
        "Setting",
        "CaptureTemplate",
        "CaptureWorkspace",
        "Reconstruct",
        "Segmentation"};

    public enum state{
        setting,
        CaptureTemplate,
        captureWorkspace,
        reconstruction,
        segmentation,
        locateMarker,
        generatePath,
        visualize
    }

    public state _state = state.setting;
    private state previous_state = state.setting;

    public GameObject windowManager;
    public GameObject LoadingAnimation, HomingAnimation;
    public GameObject[] setupObject;
    void Start()
    {
        setupSocket();
        previous_state = _state;
        for(int i=0;i<setupObject.Length;i++)
        {
            int parameter_value = setupObject[i].GetComponent<Michsky.UI.ModernUIPack.HorizontalSelector>().index;
            sendTCP(new byte[] {2, (byte)i, (byte)parameter_value });
        }
    }

    void Update()
    {
        /// Communication - Recieve from Python ///
        if(TCPsocket.Available != 0)
        {
            string stringBuffer = TCPreader.ReadLine();
            string[] stringArray = stringBuffer.Split(',');
            switch (int.Parse(stringArray[0])) // Convert to string to int
            {
                case 1: // Switch Mode
                    switchMode(int.Parse(stringArray[1]));
                    break;
                case 2: // Update parameter
                    break;
                case 3: // Event
                    switch (int.Parse(stringArray[1]))
                    {
                        case 0: // Capture Button
                            break;
                        case 1: // Loading flag
                            if (int.Parse(stringArray[2]) == 0) LoadingAnimation.active = false; // Not-Loading (Standby)
                            if (int.Parse(stringArray[2]) == 1) LoadingAnimation.active = true; // Loading (Working)
                            if (int.Parse(stringArray[2]) == 2) HomingAnimation.active = false; // Not-Homing
                            if (int.Parse(stringArray[2]) == 3) HomingAnimation.active = true; // Homing
                            break;
                        case 2:
                            
                            break;

                    }
                    break;
                default:
                    break;
            }
            //for(int i=0; i < stringArray.Length; i++)
            //{
            //    Debug.Log(stringArray[i]);
            //}
        }
        /// Update State when have change ///
        if (previous_state != _state) 
        {
            previous_state = _state;
            switchMode(_state);
        }
        /// Do State ///
        switch (_state)
        {
            case state.setting:
                break;
            case state.CaptureTemplate:
                break;
            case state.captureWorkspace:
                break;
            case state.reconstruction:
                break;
            case state.segmentation:
                break;
            case state.locateMarker:
                break;
            case state.generatePath:
                break;
            case state.visualize:
                break;
            default:
                break;
        }
    }





    public void switchMode(int newState)
    {
        _state = (state)newState;
        sendTCP(new byte[] {1, (byte)newState});
        if (newState < 3)
        {
            windowManager.GetComponent<Michsky.UI.ModernUIPack.WindowManager>().OpenPanel(WindowName[newState]);
        }
    }
    public void switchState(int newState)
    {
        _state = (state)newState;
        sendTCP(new byte[] { 1, (byte)newState });
        // windowManager.GetComponent<Michsky.UI.ModernUIPack.WindowManager>().OpenPanel(WindowName[newState]);
    }
    public void switchMode(state newState){switchMode((int)newState);}

    public bool setupSocket()// Socket setup here
    {                            
        try
        {
            TCPsocket = new TcpClient(Host, Port);
            TCPstream = TCPsocket.GetStream();
            TCPwriter = new StreamWriter(TCPstream);
            TCPreader = new StreamReader(TCPstream);
            connected = true;
            return true;
        }
        catch (Exception e)
        {
            Debug.Log("Socket error:" + e);
            return false;
        }
    }
    public void sendTCP(byte[] data)
    {
        if (TCPstream.CanWrite)
        {
            byte[] A = new byte[64];
            for (int i = 0; i < data.Length; i++)
            {
                A[i] = data[i];
            }
            TCPstream.Write(A, 0, 64);// Write byte array to socketConnection stream.
        }
        else{Debug.Log("Not connected!");}
    }
    public int getState()
    {
        return (int)_state;
    }
}


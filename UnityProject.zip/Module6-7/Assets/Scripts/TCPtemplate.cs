﻿using System.Collections;
using UnityEngine;
using System;
using System.IO;
using System.Net.Sockets;
public class TCPtemplate : MonoBehaviour
{

    bool connected = false;
    TcpClient mySocket;
    public NetworkStream theStream;
    StreamWriter theWriter;
    StreamReader theReader;
    public String Host = "127.0.0.1";
    public Int32 Port = 12345;

    void Start()
    {
        while (true)
        {
            if (setupSocket() == true) break;
        }
        
    }
    public bool setupSocket()
    {                            // Socket setup here
        try
        {
            mySocket = new TcpClient(Host, Port);
            theStream = mySocket.GetStream();
            theWriter = new StreamWriter(theStream);
            theReader = new StreamReader(theStream);
            connected = true;
            return true;
        }
        catch (Exception e)
        {
            Debug.Log("Socket error:" + e);                // catch any exceptions
            return false;
        }
    }
    public void TextMessage(string message)
    {
        if (connected)
        {
            theWriter.Write(message);
            theWriter.Flush();
        }
    }

    private void Update()
    {
        TextMessage("ABC");
        if (mySocket.Available!=0)
        {
            Debug.Log(theReader.Read());
        }
    }
}

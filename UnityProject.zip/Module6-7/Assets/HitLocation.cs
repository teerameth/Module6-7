﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HitLocation : MonoBehaviour
{
    public GameObject stateController;
    public GameObject Slider_Alpha, Slider_Z;
    byte[] packet;
    private void send(byte[] packet)
    {
        stateController.GetComponent<StateController>().sendTCP(packet);
    }

    void Update()
    {
        if (Input.GetMouseButtonUp(0))
        {
            if (stateController.GetComponent<StateController>().getState() == 0) // if  in setting state
            {
                Vector3 mousePos = Input.mousePosition;
                Ray ray = Camera.main.ScreenPointToRay(mousePos);
                RaycastHit hit;
                bool didHit = Physics.Raycast(ray, out hit);
                if (didHit)
                {
                    Vector3 screenPos = Camera.main.WorldToScreenPoint(hit.point);
                    int alpha = int.Parse(Slider_Alpha.GetComponent<Michsky.UI.ModernUIPack.RadialSlider>().valueText.text)*8;
                    int z = int.Parse(Slider_Z.GetComponent<Michsky.UI.ModernUIPack.SliderManager>().valueText.text);
                    int x = (int)((screenPos.x - 1920 + 500) / 500 * 400);
                    int y = (int)(screenPos.y / 500 * 400);
                    Debug.Log((x, y));
                    send(new byte[] { 3, 4, (byte)(x / 256), (byte)(x % 256), (byte)(y / 256), (byte)(y % 256), (byte)(z / 256), (byte)(z % 256), (byte)(alpha / 256), (byte)(alpha % 256) });
                }
            }
        }
    }
}
